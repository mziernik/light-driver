var locations = {
    hall: "korytarz",
    ktch: "Kuchnia",
    bed: "Sypialnia",
    room: "Pokój dziecięcy",
    sln: "Salon",
    bat: "Łazienka"
};


var groups = {
};

var switches = {
}