package com.utils;

/**
 * Miłosz Ziernik 2014/02/08
 */
public interface Char {

    public final static char close = '✘';
    public final static char remove = '✖';
    public final static char apply = '✔';
    public final static char dot = '•';
    public final static char star = '★';
    public final static char tripleDot = '…';
    public final static char returnKey = '↵';
    public final static char tabKey = '⇆';

    public final static char nbsp = 160; // twarda spacja
    //   ⊲⊳▷►▼

}
