package com.xml;

import org.w3c.dom.Node;

public class XText extends XElement {

    public XText(Node node) {
        super(node);

    }
}
