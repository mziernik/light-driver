package com.xml;

import org.w3c.dom.Node;

public class XCData extends XElement {

    public XCData(Node node) {
        super(node);
    }

}
