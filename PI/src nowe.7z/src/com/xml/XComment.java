package com.xml;

import org.w3c.dom.Node;

public class XComment extends XElement {

    String value;

    public XComment(Node node) {
        super(node);
    }

}
