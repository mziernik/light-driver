package com.threads;

/**
 * Miłosz Ziernik 2013/11/07
 */
public class QueueMultiThread {

}
